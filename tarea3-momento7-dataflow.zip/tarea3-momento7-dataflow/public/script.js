const taskForm = document.getElementById('taskForm');
const taskList = document.getElementById('taskList');
const filterStatus = document.getElementById('filterStatus');
const loadDemo = document.getElementById('loadDemo');

let tasks = JSON.parse(localStorage.getItem('dataflowTasks')) || [];

function saveTasks() {
  localStorage.setItem('dataflowTasks', JSON.stringify(tasks));
}

function createTaskCard(task) {
  const article = document.createElement('article');
  article.className = `task-card priority-${task.priority}`;
  article.innerHTML = `
    <h4>${task.name}</h4>
    <div class="task-meta">
      <span class="badge">${task.status}</span>
      <span>Prioridad: ${task.priority}</span>
      <span>Responsable: ${task.owner}</span>
    </div>
    <button class="delete-btn" data-id="${task.id}">Eliminar</button>
  `;
  return article;
}

function renderTasks() {
  const selectedStatus = filterStatus.value;
  const visibleTasks = selectedStatus === 'Todas'
    ? tasks
    : tasks.filter(task => task.status === selectedStatus);

  taskList.innerHTML = '';

  if (visibleTasks.length === 0) {
    taskList.innerHTML = '<p class="empty-state">No hay tareas para mostrar. Agrega una y que el sprint no se gestione solo 😄</p>';
  } else {
    visibleTasks.forEach(task => taskList.appendChild(createTaskCard(task)));
  }

  updateDashboard();
}

function updateDashboard() {
  const total = tasks.length;
  const pending = tasks.filter(task => task.status === 'Pendiente').length;
  const progress = tasks.filter(task => task.status === 'En proceso').length;
  const done = tasks.filter(task => task.status === 'Finalizada').length;
  const percentage = total === 0 ? 0 : Math.round((done / total) * 100);

  document.getElementById('totalTasks').textContent = total;
  document.getElementById('pendingTasks').textContent = pending;
  document.getElementById('progressTasks').textContent = progress;
  document.getElementById('doneTasks').textContent = done;
  document.getElementById('heroSummary').textContent = `${total} tareas registradas`;
  document.getElementById('progressBar').style.width = `${percentage}%`;
  document.getElementById('progressText').textContent =
    total === 0
      ? 'Aún no hay tareas finalizadas.'
      : `El proyecto tiene un avance del ${percentage}% según las tareas finalizadas.`;
}

taskForm.addEventListener('submit', event => {
  event.preventDefault();

  const newTask = {
    id: crypto.randomUUID(),
    name: document.getElementById('taskName').value.trim(),
    owner: document.getElementById('taskOwner').value.trim(),
    priority: document.getElementById('taskPriority').value,
    status: document.getElementById('taskStatus').value
  };

  tasks.unshift(newTask);
  saveTasks();
  renderTasks();
  taskForm.reset();
});

taskList.addEventListener('click', event => {
  if (event.target.classList.contains('delete-btn')) {
    const id = event.target.dataset.id;
    tasks = tasks.filter(task => task.id !== id);
    saveTasks();
    renderTasks();
  }
});

filterStatus.addEventListener('change', renderTasks);

loadDemo.addEventListener('click', () => {
  tasks = [
    { id: crypto.randomUUID(), name: 'Diseñar modelo de datos', owner: 'Analista de datos', priority: 'Alta', status: 'Finalizada' },
    { id: crypto.randomUUID(), name: 'Construir pipeline ETL', owner: 'Ingeniero de datos', priority: 'Alta', status: 'En proceso' },
    { id: crypto.randomUUID(), name: 'Crear tablero de indicadores', owner: 'BI Developer', priority: 'Media', status: 'Pendiente' },
    { id: crypto.randomUUID(), name: 'Validar calidad de datos', owner: 'QA Data', priority: 'Media', status: 'Pendiente' }
  ];
  saveTasks();
  renderTasks();
});

renderTasks();
